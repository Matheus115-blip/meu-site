from flask import Flask, render_template, request

app = Flask(__name__)

# Lista de veículos de exemplo
veiculos = [
    {"nome": "Carro A", "placa": "ABC-1234"},
    {"nome": "Moto B", "placa": "XYZ-5678"},
    {"nome": "Caminhão C", "placa": "LMN-9012"},
]

@app.route("/", methods=["GET", "POST"])
def index():
    resultado = veiculos
    if request.method == "POST":
        busca = request.form.get("busca", "").lower()
        resultado = [v for v in veiculos if busca in v["nome"].lower() or busca in v["placa"].lower()]
    return render_template("index.html", veiculos=resultado)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)